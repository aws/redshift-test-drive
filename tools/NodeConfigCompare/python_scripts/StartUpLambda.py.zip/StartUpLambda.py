import boto3
import botocore.exceptions as be
import traceback
import json
import urllib3
import os
def handler(event, context):
    print(event)
    res = {}
    if event['RequestType'] != 'Delete':
        try:
            system_config = {}
            for item, value in sorted(os.environ.items(), key=lambda x: x[0]):
                system_config[item] = value
            user_config =  get_json_config_from_s3(os.environ['USER_CONFIG_JSON_S3_PATH'])
            master_user_name, database_name,port, source_node_type, source_number_of_nodes = get_db_params(user_config)
            system_config["MASTER_USER_NAME"] = master_user_name
            system_config["DATABASE_NAME"] = database_name
            system_config["PORT"] = port
            system_config["SOURCE_NODE_TYPE"] = source_node_type
            system_config["SOURCE_NUMBER_OF_NODES"] = source_number_of_nodes
            save_pricing_data(os.environ['PRICING_URI'], int(os.environ['REMOVE_HEADER_LENGTH']), os.environ['PRICING_FILE'])
            system_config["EXTERNAL_SCHEMA_SCRIPT"] = "create external schema "+ os.environ['GLUE_DATABASE_NAME'] + " from data catalog database '"+ os.environ['GLUE_DATABASE_NAME'] +"' iam_role '"+ os.environ['REDSHIFT_IAM_ROLE'] +"'"
            workgroup_subnet_list = event['ResourceProperties']['RedshiftSubnetList']
            system_config["WORKGROUP_SUBNET"] = ','.join(workgroup_subnet_list)
            s3_put_config_file(system_config, os.environ['SYSTEM_CONFIG_JSON_S3_PATH'])
            #response = boto3.client('stepfunctions').start_execution(
            #    stateMachineArn=os.environ['STEP_FUNCTION_ARN']
            #)
            response = 'Step function started'
            res = {'master_user_name': master_user_name, 'database_name': database_name, 'port': port}
        except Exception as e:
            res = {'error': e.response['Error']['Code'] if isinstance(e, be.ClientError) else 'failed'}
            print(traceback.format_exc())
            raise
        print(response)
def get_json_config_from_s3(script_s3_path):
    bucket, key = script_s3_path.replace("s3://", "").split("/", 1)
    obj = boto3.client('s3').get_object(Bucket=bucket, Key=key)
    return json.loads(obj['Body'].read().decode('utf-8'))
def s3_put_config_file(dict_obj, s3_path):
    s3 = boto3.client('s3')
    bucket, key = s3_path.replace("s3://", "").split("/", 1)
    s3.put_object(Body=json.dumps(dict_obj), Bucket=bucket, Key=key)
def save_pricing_data(pricing_uri, remove_header_length, price_info_file_s3_path):
    bucket, key = price_info_file_s3_path.replace("s3://", "").split("/", 1)
    price_content = urllib3.PoolManager().request('GET', pricing_uri).data.decode("utf-8")
    pricing_content_list = price_content.split('\n')
    new_content = '\n'.join(pricing_content_list[remove_header_length:])
    boto3.client('s3').put_object(Body=new_content, Bucket=bucket, Key=key)
def get_clusters(client, cluster_identifier):
    try:
        cluster_identifiers = []
        for cluster in client.describe_clusters().get('Clusters'):
            if cluster_identifier in cluster.get('ClusterIdentifier'):
                cluster_identifiers.append(cluster.get('ClusterIdentifier'))
        return cluster_identifiers
    except be.ClientError as e:
        msg = e.response['Error']['Code']
        if msg == 'ClusterNotFound':
            status = 'N/A'
        else:
            raise
    return status
def get_db_params(user_config:dict):
    if user_config.get('SNAPSHOT_ID') is None or user_config.get('SNAPSHOT_ID') == "N/A":
        master_user_name=os.environ['DEFAULT_MASTER_USER']
        database_name=os.environ['DEFAULT_DATABASE_NAME']
        port=os.environ['DEFAULT_PORT']
        source_node_type=""
        source_number_of_nodes=0
    else:
        resp = boto3.client('redshift').describe_cluster_snapshots(SnapshotIdentifier=user_config.get('SNAPSHOT_ID'))
        master_user_name = resp['Snapshots'][0]['MasterUsername']
        database_name = resp['Snapshots'][0]['DBName']
        port = resp['Snapshots'][0]['Port']
        source_node_type=resp['Snapshots'][0]['NodeType']
        source_number_of_nodes=resp['Snapshots'][0]['NumberOfNodes']
    return (master_user_name, database_name, port, source_node_type, source_number_of_nodes)